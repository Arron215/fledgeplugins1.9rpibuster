A Fledge South plugin for the DHT11
====================================

A simple sensor plugin for a DHT11 temperature and humidity sensor, for Raspberry Pi.
