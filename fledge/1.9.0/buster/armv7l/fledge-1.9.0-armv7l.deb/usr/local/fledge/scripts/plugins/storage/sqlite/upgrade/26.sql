INSERT OR IGNORE INTO scheduled_processes ( name, script ) VALUES ( 'south_c',   '["services/south_c"]' );

