create index readings_ix3 on readings(user_ts);
