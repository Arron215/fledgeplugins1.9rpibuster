--
-- DROP the column: read_key   uuid
--
ALTER TABLE fledge.readings DROP COLUMN read_key;
