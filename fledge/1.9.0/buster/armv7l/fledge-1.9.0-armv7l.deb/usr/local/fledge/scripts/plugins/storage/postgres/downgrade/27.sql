-- Notification log code NTFCL
DELETE from fledge.log_codes WHERE code = 'NTFCL';
