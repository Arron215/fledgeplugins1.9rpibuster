.. |br| raw:: html

   <br />


********
Kerberos
********

This directory should contain the ketytab file named **piwebapi_kerberos_https.keytab** needed for the Kerberos authentication.

|br| |br|
