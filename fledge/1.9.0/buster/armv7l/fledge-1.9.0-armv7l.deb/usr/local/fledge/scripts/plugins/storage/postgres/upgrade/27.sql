-- Remove index on fledge.readings read_key
DROP INDEX IF EXISTS fledge.readings_ix1;
