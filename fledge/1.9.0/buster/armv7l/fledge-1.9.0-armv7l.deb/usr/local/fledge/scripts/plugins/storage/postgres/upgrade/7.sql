CREATE INDEX statistics_history_ix2
    ON fledge.statistics_history(key);
