drop index readings_ix3;
