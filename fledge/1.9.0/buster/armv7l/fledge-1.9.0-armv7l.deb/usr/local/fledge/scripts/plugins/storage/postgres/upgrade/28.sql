-- Add audit log key NTFCL
INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFCL', 'Notification Cleared' );
