-- Remove packages table
DROP TABLE IF EXISTS fledge.packages;
