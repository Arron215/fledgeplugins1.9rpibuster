CREATE INDEX readings_ix2
    ON readings USING btree (asset_code);
