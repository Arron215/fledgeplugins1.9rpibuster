INSERT INTO fledge.log_codes ( code, description )
     VALUES ( 'NTFDL', 'Notification Deleted' );
