DROP INDEX readings_ix2;
