DELETE from fledge.log_codes WHERE code = 'NTFDL';
