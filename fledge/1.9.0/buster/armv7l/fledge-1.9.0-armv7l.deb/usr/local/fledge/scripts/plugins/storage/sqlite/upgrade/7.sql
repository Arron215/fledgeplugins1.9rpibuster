CREATE INDEX statistics_history_ix2
    ON statistics_history (key);

