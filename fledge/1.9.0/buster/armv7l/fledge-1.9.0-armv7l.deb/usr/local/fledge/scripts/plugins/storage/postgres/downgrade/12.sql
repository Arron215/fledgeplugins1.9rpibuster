DROP INDEX statistics_history_ix3;
